# Catálogo Online

Proyecto inicializado con React (Vite), Tailwind CSS, y Node.js (Express).